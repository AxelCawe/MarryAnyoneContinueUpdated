If you are not using the Mod Configuration Menu, you may change settings using the config.json file.
This can be done at anytime and will apply to all characters.

Adoption Chance goes from 0.00 (0%) to 1.00 (100%).

Below is a list of values for the following settings for reference.

Difficulty:
Very Easy
Easy
Realistic

SexualOrientation:
Heterosexual
Homosexual
Bisexual